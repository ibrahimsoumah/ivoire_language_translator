-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 09 juil. 2020 à 01:20
-- Version du serveur :  10.4.11-MariaDB
-- Version de PHP : 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `login_utilisateur`
--

-- --------------------------------------------------------

--
-- Structure de la table `tableau recherche`
--

CREATE TABLE `tableau recherche` (
  `id` int(11) NOT NULL,
  `search_text` varchar(500) NOT NULL,
  `langue_start` varchar(50) NOT NULL,
  `langue_end` varchar(50) NOT NULL,
  `ip` double NOT NULL,
  `statuts` tinyint(1) NOT NULL,
  `date_enrg` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `tableau_activite`
--

CREATE TABLE `tableau_activite` (
  `id` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `action` varchar(500) NOT NULL,
  `date_enrg` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `tableau_data`
--

CREATE TABLE `tableau_data` (
  `id` int(11) NOT NULL,
  `texte1` varchar(300) NOT NULL,
  `langue_start` text NOT NULL,
  `texte2` text NOT NULL,
  `langue_end` text NOT NULL,
  `audio` varchar(270) NOT NULL,
  `status` varchar(50) NOT NULL,
  `date_enrg` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `tableau_data`
--

INSERT INTO `tableau_data` (`id`, `texte1`, `langue_start`, `texte2`, `langue_end`, `audio`, `status`, `date_enrg`) VALUES
(1, 'bonjour', 'francais', 'mo ah eh', 'baoule', 'daudios/no-game-no-life-opening-full.mp3 ', '', '2020-07-04 23:24:36'),
(2, 'good morning', 'anglais', 'mo ah eh', 'baoule', 'daudios/stromae-formidable-ceci-nest-pas-une-lecon.mp3 ', '', '2020-07-05 12:59:27');

-- --------------------------------------------------------

--
-- Structure de la table `tableau_langue_end`
--

CREATE TABLE `tableau_langue_end` (
  `id` int(11) NOT NULL,
  `langue` varchar(50) NOT NULL,
  `date_enrg` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `tableau_langue_start`
--

CREATE TABLE `tableau_langue_start` (
  `id` int(11) NOT NULL,
  `langue` varchar(50) NOT NULL,
  `date_enrg` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `tableau_utilisateur`
--

CREATE TABLE `tableau_utilisateur` (
  `id` int(11) NOT NULL,
  `nomPrenom` varchar(270) NOT NULL,
  `email` varchar(270) NOT NULL,
  `mdp` text NOT NULL,
  `roless` varchar(200) NOT NULL,
  `date_enrg` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `tableau_utilisateur`
--

INSERT INTO `tableau_utilisateur` (`id`, `nomPrenom`, `email`, `mdp`, `roless`, `date_enrg`) VALUES
(1, 'soumah iibrahim michot', 'ibrahim885209@gmail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'operateur', '2020-06-21'),
(5, 'test operateur', 'ibrahimmichot73@outlook.fr', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'operateur', '2020-07-08');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `tableau recherche`
--
ALTER TABLE `tableau recherche`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tableau_activite`
--
ALTER TABLE `tableau_activite`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`,`iduser`);

--
-- Index pour la table `tableau_data`
--
ALTER TABLE `tableau_data`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tableau_langue_end`
--
ALTER TABLE `tableau_langue_end`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tableau_langue_start`
--
ALTER TABLE `tableau_langue_start`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tableau_utilisateur`
--
ALTER TABLE `tableau_utilisateur`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `tableau recherche`
--
ALTER TABLE `tableau recherche`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `tableau_activite`
--
ALTER TABLE `tableau_activite`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `tableau_data`
--
ALTER TABLE `tableau_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `tableau_langue_end`
--
ALTER TABLE `tableau_langue_end`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `tableau_langue_start`
--
ALTER TABLE `tableau_langue_start`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `tableau_utilisateur`
--
ALTER TABLE `tableau_utilisateur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
