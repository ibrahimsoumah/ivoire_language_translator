<?php
session_start();

// connexion bdd
//autre methode de connexion $bdd = new PDO('mysql:host=127.0.0.1;dbname=login_utilisateur', 'root', '');
try {
    $bdd = new PDO('mysql:host=localhost;dbname=login_utilisateur', 'root', '');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}


// 



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="adminAcceuil.css" type="text/css">
    <title>Document</title>
</head>

<body>

    <main class="container">
        <div class="row">
            <div class="col-6">
                <form action="test.php" method="POST">
                    <br>
                    <select name="lang_start"><br>
                        <option value="francais">francais</option>
                        <option value="anglais">anglais</option>
                    </select>

                    <div>
                        <br>
                        <textarea name="texte1" rows="4" cols="50"></textarea>
                        <input type="submit" name="traduire" value="Traduire">
                    </div>
                </form>
            </div>
            <?php

            if (isset($_POST['lang_start']['0']) and isset($_POST['lang_start']['1'])) {
                if (isset($_POST['texte1']) == "bonjour" or "good morning") {
                    echo isset($_POST['texte2']) . ' <div class="col-6">
                <br>
                <select name="lang_end"><br>
                    <option value="francais">malinke</option>
                  
                </select>
                <form action="test.php" method="POST">
                    <h6>texte traduit</h6>
                    <textarea name="texte2" id="traduitbaoule" rows="4" cols="50">ani so gomam</textarea>

                </form>
            </div>';
                } else {
                    echo "error";
                }
            }
            // <h6>texte traduit</h6><br>
            //                     <textarea name="texte2" id="traduitbaoule" rows="4" cols="50">Mo arè oh!</textarea>';

            ?>


        </div>
    </main>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>

</html>