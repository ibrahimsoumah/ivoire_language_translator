<?php

session_start();

// connexion bdd
//autre methode de connexion $bdd = new PDO('mysql:host=127.0.0.1;dbname=login_utilisateur', 'root', '');
try {
    $bdd = new PDO('mysql:host=localhost;dbname=login_utilisateur', 'root', '');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

// verifier 
if (isset($_POST['connexionusers'])) {

    // securiser nos variables   
    $emailconnect = htmlspecialchars($_POST['emailconnect']);
    $mdpconnect = sha1($_POST['mdpconnect']); //sha1 hachage du mot de passe le crypte pour ne pas quil soit retrouve

    // renvoie un message si tous les champs ne sont pas rempli
    if (!empty($emailconnect) and !empty($mdpconnect)) {

        // verifie si lutilisateur existe bien
        $requser = $bdd->prepare("SELECT * FROM tableau_utilisateur WHERE email = ? AND mdp = ?");
        $requser->execute(array($emailconnect, $mdpconnect));
        $champ = $requser->fetch();
        // verifie si lutilisateur existe bien
        if ($champ['email'] == $emailconnect) {

            $userinfo = $requser->fetch();
            $_SESSION['id'] = $userinfo['id'];
            $_SESSION['nomPrenom'] = $userinfo['nomPrenom'];
            $_SESSION['email'] = $userinfo['email'];

            header("Location: superviseurAcceuil.php" . $_SESSION['id']);
        } else {
            $erreur = "adresse mail ou mot de passe errone";
        }
    } else {
        $erreur = "tous les champs doivents etres completes";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVOIRE LANGUAGE TRANSLATOR</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/connexion.css">
</head>

<body>

    <main class="container-fluid centrers">
        <div class="row">
            <div class="conteneur1">


                <!-- logo ITL -->
                <div class="itllogo">
                    <img src="image/LogoIvoireLanguagesTranslatorfondblanc.png" height="230px" width="260px" title="LOGO IVOIRE LANGUAGE TRANSLATOR" alt="LOGO IVOIRE LANGUAGE TRANSLATOR">
                </div>
                <div class="texteITL">
                    <p>
                        <span style="color: rgb(12, 199, 12);" class="h3">Ivoire</span>
                        <span style="color: rgb(255, 145, 77);" class="h3"> Language</span>
                        <span style="color: rgb(12, 199, 12);" class="h3"> Translator</span>
                    </p>
                </div>
                <br><!--  -->

                <!-- redirige vers la page dinsciption page dacceuil -->
                <p class="inscription">
                    Vous n'avez pas de compte ? <a href="index.php"> S’inscrire</a>
                </p><br>
                <!---->


                <!-- texte connexion -->
                <span style="color:rgb(166, 166, 166);" class="connexiontexte h5"><u>CONNEXION</u></span>


                <!--le formulaire -->
                <div class="formulaire">
                    <form method="POST" action="connexion.php">

                        <!-- email -->
                        <div class="form-group centrer1" style="margin-top: 30px;">
                            <label><strong>Email</strong></label><br>
                            <div>
                                <input type="email" name="emailconnect" placeholder="Entrer votre email" class="form-control col-11 postion1" style="background: #e1e1e1;">
                            </div>
                        </div>
                        <br>


                        <!-- mot de passe -->
                        <div class="form-group centrer1">
                            <label><strong>MOT DE PASSE</strong></label><br>
                            <div>
                                <input type="password" name="mdpconnect" placeholder="Votre mot de passe" class="form-control col-11 postion1" style="background: #e1e1e1;">
                            </div>
                        </div>


                        <!-- bouton envoyer -->
                        <button class="btn btn-warning" name="connexionusers" type="submit" style="color: white;"><b>CONNEXION</b></button>

                        <?php
                        // texte derreur si aucun champ nest rempli
                        if (isset($erreur)) {
                            echo '</br></br></br><br> ' . '<font color="red">' . $erreur . "</fonts>";
                        }
                        ?>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
</body>

</html>