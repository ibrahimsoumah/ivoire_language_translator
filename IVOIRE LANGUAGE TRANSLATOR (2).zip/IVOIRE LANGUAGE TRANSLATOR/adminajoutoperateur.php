<?php
if (isset($_REQUEST['nomPrenom'], $_REQUEST['email'], $_REQUEST['type'], $_REQUEST['mdp'])) {
    // récupérer le nom d'utilisateur et supprimer les antislashes ajoutés par le formulaire
    $username = stripslashes($_REQUEST['nomPrenom']);
    $username = mysqli_real_escape_string($conn, $username);
    // récupérer l'email et supprimer les antislashes ajoutés par le formulaire
    $email = stripslashes($_REQUEST['email']);
    $email = mysqli_real_escape_string($conn, $email);
    // récupérer le mot de passe et supprimer les antislashes ajoutés par le formulaire
    $password = stripslashes($_REQUEST['mdp']);
    $password = mysqli_real_escape_string($conn, $password);
    // récupérer le type (user | admin)
    $type = stripslashes($_REQUEST['roless']);
    $type = mysqli_real_escape_string($conn, $type);

    $query = "INSERT into `utilisateur` (username, email, roless, mdp)
VALUES ('$username', '$email', '$type', '" . hash('sha256', $password) . "')";
    $res = mysqli_query($conn, $query);

    if ($res) {
        echo "<div class='sucess'>
    <h3>L'utilisateur a été créée avec succés.</h3>
    <p>Cliquez <a href='home.php'>ici</a> pour retourner à la page d'accueil</p>
</div>";
    }
} else {
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="css/superviseurAcceuil.css" type="text/css">
    <title>ADMIN AJOUT OPERATEUR</title>
</head>

<body>
    <?php
    include("include/adminheader.php");
    ?>
    <br>
    <main class="container">
        <div class="text-center bloc  p-2 ">
            <div><span class="textActivite text-nowrap">AJOUT / OPERATEUR</span></div>
        </div>
        <br>


        <div class="row">
            <div class="col-12 englobe ml-3">

                <div class="formulaire">
                    <form action="adminajoutoperateur.php" method="POST">
                        <div class="row m-1">
                            <div class="form-group ">
                                <label class="label" style="color: #9d9a9a;">NOM ET PRENOMS</label><br>
                                <input type="text " name="nomPrenom" style="background-color: #fafafa; border:none; height:35px;width:250px;">
                            </div>
                            <div class="float-right phonetique">
                                <label class="label " style="color: #9d9a9a;">EMAIL</label><br>
                                <input class="ml-10" name="email" type="email" style="background-color: #fafafa; border:none; height:35px;width:250px;">
                            </div>
                        </div>
                        <br>
                    </form>
                </div>

                <div class="formulaire">
                    <form>
                        <div class="form-group ">
                            <label class="label" style="color: #9d9a9a;">MOT DE PASSE</label><br>
                            <input type="password" name="mdp" style="background-color: #fafafa; border:none; height:35px;width:250px;">
                        </div>
                        <div class="float-right phonetique">
                            <label class="label " style="color: #9d9a9a;">role</label><br>
                            <select class="ml-10" style="background-color: #fafafa; border:none; height:35px;width:250px;">
                                <option value="role">operateur</option>
                            </select>
                        </div>
                        <!-- <div class="float-right phonetique">
                            <label class="label " style="color: #9d9a9a;"></label><br>
                            <input class="ml-10" type="password" style="background-color: #fafafa; border:none; height:35px;width:250px;">
                        </div> -->
                    </form>
                </div>
                <br>
                <div class="ml-1" style="font-size: 2em;">
                    <!-- <input type="button" name="supprimer" value="SUPPRIMEZ" style="background-color: #82b7ef; color:white;border:none;font-weight:bold;border-radius: 50 px;"> -->
                    <!-- <button type="button" name="button1" class="btn"><a href=" adminsupprimeroperateur.php">SUPPRIMER</a></button> -->
                    <button type="submit" class="btn ml-2" name="ajouter" class="btn">ajouter</button>
                    <!-- <input type="button" name="ajouter" class="ml-3" value="AJOUTER" style="background-color: #82b7ef; color:white;border:none;font-weight:bold;border-radius: 50 px;"> -->
                </div>

            </div>
        </div>
        <br>
    </main>

    <?php
    include("include/superviseurfooter.php");
    ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>

</html>