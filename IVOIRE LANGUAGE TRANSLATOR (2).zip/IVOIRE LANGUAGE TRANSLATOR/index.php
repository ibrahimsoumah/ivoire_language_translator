<?php
// connexion bdd
//autre methode de connexion $bdd = new PDO('mysql:host=127.0.0.1;dbname=login_utilisateur', 'root', '');
try {
    $bdd = new PDO('mysql:host=localhost;dbname=login_utilisateur', 'root', '');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}


// test pour voir si l'utilisateur entre de bonne valeurs
if (isset($_POST['sinscire'])) {
    //securiser nos variables    
    $nomPrenom = htmlspecialchars($_POST['nomPrenom']);
    $email = htmlspecialchars($_POST['email']);
    $email2 = htmlspecialchars($_POST['email2']);
    $mdp = sha1($_POST['mdp']); // hacher le mdp( sha1() ) pour ne pas que le mdp soit retrouve
    $mdp2 = sha1($_POST['mdp2']);
    $roless = htmlspecialchars($_POST['roless']);

    // voir si tous les champs ont ete complete
    if (!empty($_POST['nomPrenom']) and !empty($_POST['email']) and !empty($_POST['email2']) and !empty($_POST['mdp']) and !empty($_POST['mdp2']) and !empty($_POST['roless'])) {

        // tester si le nom est plus grande que 100 caracteres
        $nomPrenomlength = strlen($nomPrenom);
        if ($nomPrenomlength <= 270) {

            // voir si les 2 mails correspondent
            if ($email == $email2) {

                // pour voir si ces un email
                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {

                    // permet de verifier quil ny a pas plusieurs fois le meme email pour eviter les doublons 
                    $reqemail = $bdd->prepare("SELECT email FROM tableau_utilisateur WHERE email=?");
                    $reqemail->execute(array($email));

                    $champ = $reqemail->fetch();

                    if (!empty($champ['email'])) {
                        $emailexist = 1;
                    } else {
                        $emailexist = 0;
                    }



                    //$emailexist = $reqemail->rowCount(); //rowcount compter le nomdre de colonne avant
                    if ($emailexist == 0) {

                        $date = date('Y-m-d');
                        // voir si les mdp correspondent
                        if ($mdp == $mdp2) {
                            // fonction pour l'inscription reussi
                            $insertmbr = $bdd->prepare("INSERT INTO tableau_utilisateur(nomPrenom,email,mdp,roless,date_enrg) VALUES(:nomPrenom,:email,:mdp,:roless,:date_enrg)");
                            $insertmbr->execute(array("nomPrenom" => $nomPrenom, "email" => $email, "mdp" => $mdp, "roless" => $roless, "date_enrg" => $date));
                            $erreur = "votre compte a bien éte créer";

                            // pour rediriger lutilisateur vers la page index
                            // header('Location: index.php');
                        } else {
                            $erreur = "vos mot de passe ne correspondent pas";
                        }
                    } else {
                        $erreur = "adresse email deja utilisé";
                    }
                } else {
                    $erreur = "votre adresse mail nes pas valide";
                }
            } else {
                $erreur = "vos adresses mails ne correspondent pas";
            }
        } else {
            $erreur = "votre nom ne doit pas depasser 270 caracteres ";
        }
    } else {
        $erreur = "tous les champs doivent etre complété";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVOIRE LANGUAGE TRANSLATOR</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="css/connexion.css">
</head>

<body>

    <main class="container-fluid centrers">
        <div class="row">
            <div class="conteneur1">


                <!-- logo ITL -->
                <div class="itllogo">
                    <img src="image/LogoIvoireLanguagesTranslatorfondblanc.png" height="230px" width="260px" title="LOGO IVOIRE LANGUAGE TRANSLATOR" alt="LOGO IVOIRE LANGUAGE TRANSLATOR">
                </div>
                <div class="texteITL">
                    <p>
                        <span style="color: rgb(12, 199, 12);" class="h3">Ivoire</span>
                        <span style="color: rgb(255, 145, 77);" class="h3"> Language</span>
                        <span style="color: rgb(12, 199, 12);" class="h3"> Translator</span>
                    </p>
                </div>
                <br>
                <br><!-- -->


                <!-- texte menant a la page de connexion si lutilisateur existe deja -->
                <p class="inscription">
                    vous avez deja un compte ? <a href="connexion.php"> Se Connecter</a>
                </p>
                <br>


                <!-- texte inscription -->
                <span style="color:rgb(166, 166, 166);" class="connexiontexte h5"><u>INSCRIPTION</u></span>



                <!-- le formulaire -->
                <div class="formulaire">
                    <form method="POST" action="index.php">

                        <!-- nom -->
                        <div class="form-group centrer1" style="margin-top: 30px;">
                            <label><strong>NOM ET PRENOM</strong></label><br>
                            <div>
                                <input type="text" name="nomPrenom" placeholder="Exemple : Soumah Ibrahim Michot" value="<?php if (isset($nomPrenom)) {
                                                                                                                                echo $nomPrenom;
                                                                                                                            } ?>" class="form-control col-11 postion1" style="background: #e1e1e1;">
                            </div>
                        </div>

                        <!-- email -->
                        <div class="form-group centrer1" style="margin-top: 30px;">
                            <label><strong>Email</strong></label><br>
                            <div>
                                <input type="email" name="email" placeholder="Exemple : no_reply@simplonline.co" value="<?php if (isset($email)) {
                                                                                                                            echo $email;
                                                                                                                        } ?>" class="form-control col-11 postion1" style="background: #e1e1e1;">
                            </div>
                        </div>

                        <!-- confirmation email -->
                        <div class="form-group centrer1" style="margin-top: 30px;">
                            <label><strong>Confirmer votre email</strong></label><br>
                            <div>
                                <input type="email" name="email2" placeholder="Confirmer votre email" value="<?php if (isset($email2)) {
                                                                                                                    echo $email2;
                                                                                                                } ?>" class="form-control col-11 postion1" style="background: #e1e1e1;">
                            </div>
                        </div>

                        <!-- mot de passe -->
                        <div class="form-group centrer1">
                            <label> <strong> MOT DE PASSE </strong> </label> <br>
                            <div>
                                <input type="password" name="mdp" placeholder="entrer un mot de passe" class="form-control col-11 postion1" style="background: #e1e1e1;">
                            </div>
                        </div>

                        <!-- confirmation mot de passe -->
                        <div class="form-group centrer1">
                            <label> <strong> Confirmer votre mot de passe </strong> </label> <br>
                            <div>
                                <input type="password" name="mdp2" placeholder="confirmer votre mot de passe" class="form-control col-11 postion1" style="background: #e1e1e1;">
                            </div>
                        </div>

                        <!-- les differents roles -->
                        <div class="form-group centrer1">
                            <label for="roless"> <strong> Role : </strong> </label>
                            <select class="form-control taille" name="roless" id="role" value="<?php if (isset($roless)) {
                                                                                                    echo $roless;
                                                                                                } ?>" style="background: #e1e1e1;">
                                <option value="role"> Choisir un role </option>
                                <option value="superviseur"> superviseur </option>
                                <option value="admin"> administrateur </option>
                                <option value="operateur"> operateur </option>
                            </select>
                        </div>


                        <!-- bouton envoyer -->
                        <button class="btn btn-warning" name="sinscire" value="index.php" type="submit" style="color: white;">
                            <b>S'INSCRIRE</b>
                        </button>


                        <?php
                        // texte derreur si aucun champ nest rempli
                        if (isset($erreur)) {
                            echo '</br></br></br><br> ' . '<font color="red">' . $erreur . "</fonts>";
                        }

                        //    texte dinscription reussi
                        ?>

                    </form>
                </div>

            </div>
        </div>
    </main>


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
</body>

</html>