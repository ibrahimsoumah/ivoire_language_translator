<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="css/superviseurAcceuil.css" type="text/css">
    <title>operateur inserer</title>
</head>

<body>
    <?php
    include("include/operateurheader.php");
    ?>
    <br>
    <main class="container">
        <div class="text-center bloc  p-2 ">
            <div><span class="textActivite text-nowrap">AJOUT INFORMATIONS</span></div>
        </div>
        <br>
        <div class="row">

            <div class="col-12 englobe">
                <div class="admin col-1 d-flex">
                    <button type="button" role="button" class="btn"><a href="operateurinserer.php">MOT</a></button>
                    <button type="button" role="button" class="btn ml-2"><a href="operateurinserer2.php">PHRASE</a></button>

                </div>
                <br>

                <div class="col-12 avantformulaire">

                    <form id="myForm" action="operateurinserer.php" method="post" enctype="multipart/form-data">


                        <div class="form-group ">
                            <label class="label" style="color: #9d9a9a;">MOT a traduire</label><br>
                            <input type="text" name="texte1" style="background-color: #fafafa; border:none; height:35px;width:250px;">
                        </div>


                        <div class="">
                            <label class="label  " style="color: #9d9a9a;">ASSOCIEZ L'AUDIO</label><br><br>
                            <input class="" type="file" name="audio" id="audio" accept="audio/mpeg, audio/ogg, audio/wav">

                        </div>

                        <div class="form-group">
                            <label class="label" style="color: #9d9a9a;">langue dorigine</label><br>
                            <select name="langue_start" style="color: #9d9a9a; width: 200px;">
                                <option value="francais">francais</option>
                                <option value="anglais">anglais</option>
                            </select>
                        </div>


                        <div class="form-group float-right">
                            <label class="label" style="color: #9d9a9a;">langue de traduction</label><br>
                            <select name="langue_end" style="color: #9d9a9a; width: 200px;">
                                <option value=""></option>
                                <option value="baoule">Baoulé</option>
                                <option value="Bété">Bété</option>
                                <option value="Akyé">Akyé</option>
                                <option value=" Abidji"> Abidji</option>
                                <option value="Abouré">Abouré</option>
                                <option value="Gwa">Gwa</option>
                                <option value="Abbey">Abbey</option>
                                <option value="Adioukrou">Adioukrou</option>
                                <option value="Ehotilé">Ehotilé</option>
                                <option value="Avikam">Avikam</option>
                                <option value="Alladian">Alladian</option>
                                <option value="Ega">Ega</option>
                                <option value="Ebrié">Ebrié</option>
                                <option value="Elomouin">Elomouin</option>
                                <option value="Essouma">Essouma</option>
                                <option value="N’zima">N’zima</option>
                                <option value="Bron">Bron</option>
                                <option value="Agni">Agni</option>
                                <option value="Yowré">Yowré</option>
                                <option value="Mahou">Mahou</option>
                                <option value="Malinké">Malinké</option>
                                <option value="Mangoro">Mangoro</option>
                                <option value="Nomou">Nomou</option>
                                <option value="Gouro">Gouro</option>
                                <option value="Koyaka">Koyaka</option>
                                <option value=" Wan"> Wan</option>
                                <option value="Gagou">Gagou</option>
                                <option value="Toura">Toura</option>
                                <option value="Dan">Dan</option>
                                <option value="Gbin">Gbin</option>
                                <option value=" Niarafolo"> Niarafolo</option>
                                <option value="Ténéwéré">Ténéwéré</option>
                                <option value="Koulango">Koulango</option>
                                <option value="Nafana">Nafana</option>
                                <option value="Tiembara">Tiembara</option>
                                <option value="Degha">Degha</option>
                                <option value="Lohon">Lohon</option>
                                <option value="Tagouana">Tagouana</option>
                                <option value="Lobi">Lobi</option>
                                <option value="Djamala">Djamala</option>
                                <option value="Djimini">Djimini</option>
                                <option value="Birifor">Birifor</option>
                                <option value="Samassogo">Samassogo</option>
                                <option value="Djafolo">Djafolo</option>
                                <option value="Camara">Camara</option>
                                <option value="Lohron">Lohron</option>
                                <option value="Wobé">Wobé</option>
                                <option value="Bakwé">Bakwé</option>
                                <option value="Dida">Dida</option>
                                <option value="Godié">Godié</option>
                                <option value="Guéré">Guéré</option>
                                <option value="Kroumen">Kroumen</option>
                                <option value="Kousié">Kousié</option>
                                <option value="Niaboua">Niaboua</option>
                                <option value="Néyo">Néyo</option>
                                <option value="Wini">Wini</option>

                            </select>
                            <div class=" ml-5 mb-7 float-right">
                                <label class="label ml-5 " style="color: #9d9a9a;">TRADUCTION</label><br><br>
                                <input class="ml-5" type="text" name="texte2">

                            </div>



                        </div>

                        <center><button type="submit" name="enregistrer" class="btn bg-danger text-dark">Enregistrer</button></center>


                    </form>
                    <?php
                    include_once('db.php');



                    if (isset($_POST['enregistrer'])) {
                        $texte1 = $_POST['texte1'];
                        $langue_start = $_POST['langue_start'];
                        $langue_end = $_POST['langue_end'];
                        $texte2 = $_POST['texte2'];
                        $target_dir = "daudios/";
                        $target_file = $target_dir . basename($_FILES["audio"]["name"]);


                        $sql = "INSERT INTO tableau_data (texte1, langue_start, langue_end, texte2, audio)
VALUES ('$texte1', '$langue_start', '$langue_end', '$texte2' , '$target_file ')";

                        if (move_uploaded_file($_FILES['audio']['tmp_name'], $target_file)) {
                            echo "Audio saved";
                        }
                        if (mysqli_query($conn, $sql)) {


                            echo '<script language="Javascript">';
                            echo 'document.location.replace("./operateurinserer.php")';
                            echo ' </script>';
                        } else {
                            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                        }
                    } else {
                        echo "";
                    }


                    mysqli_close($conn);



                    ?>

                </div>

            </div>
    </main>



    <?php
    include("include/superviseurfooter.php");
    ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>

</html>