  <?php
    session_start();

    if (isset($_SESSION[''])) {
        $username = $_SESSION['username'];
        if (isset($_POST['enregistrer'])) {
            $email = $_POST['email'];
            $ancienmdp = $_POST['ancienmdp'];
            $newmdp = $_POST['newmdp'];

            if ($email && $ancienmdp && $newmdp) {
            } else {
                echo " veuiller saisir tous les champs";
            }
            $bdd = mysqli_connect('localhost', 'root', '') or die('error');
            mysqli_select_db('tableau_utilisateur', '');
            $query = mysqli_query("SELECT * FROM tableau_utilisateur WHERE mdp='$ancienmdp'", '');
            $rows = mysqli_num_rows($query);
            if ($rows == 1) {
            } else {
                echo "votre ancien password est incorrect";
            }
        }
    }

    ?>

  <!DOCTYPE html>
  <html lang="en">

  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
      <link rel="stylesheet" href="css/superviseurAcceuil.css" type="text/css">
      <title>operateur parametres</title>
  </head>

  <body>
      <?php
        include("include/operateurheader.php");
        ?>
      <br>
      <main class="container">
          <div class="text-center bloc  p-2 ">
              <div><span class="textActivite text-nowrap">PARAMETRES / OPERATEUR</span></div>
          </div>
          <br>

          <div class="row">
              <div class="col-12 englobe ml-3">

                  <div class="formulaire">
                      <form action="operateurparametres.php" method="POST">
                          <div class="row m-1">
                              <div class="form-group ">
                                  <label class="label" style="color: #9d9a9a;">EMAIL</label><br>
                                  <input type="email" name="email" style="background-color: #fafafa; border:none; height:35px;width:250px;">
                              </div>

                          </div>


                  </div>

                  <div class="formulaire">

                      <div class="form-group ">
                          <label class="label" style="color: #9d9a9a;">ANCIEN MOT DE PASSE</label><br>
                          <input type="password" name="ancienmdp" style="background-color: #fafafa; border:none; height:35px;width:300px;">
                      </div>
                      <div class="form-group ">
                          <label class="label" style="color: #9d9a9a;"> NOUVEAU MOT DE PASSE</label><br>
                          <input type="password" name="newmdp" style="background-color: #fafafa; border:none; height:35px;width:300px;">
                      </div>

                      <!-- <div class="float-right phonetique">
                            <label class="label " style="color: #9d9a9a;"></label><br>
                            <input class="ml-10" type="password" style="background-color: #fafafa; border:none; height:35px;width:250px;">
                        </div> -->

                  </div>
                  <br>
                  <div class="ml-1" style="font-size: 2em;">
                      <button type="submit" name="enregistrer" class="btn">ENREGISTRER</button>
                  </div>
                  </form>

              </div>
          </div>
          <br>
      </main>


      <?php
        include("include/superviseurfooter.php");
        ?>
      <!-- JS, Popper.js, and jQuery -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>

  </html>