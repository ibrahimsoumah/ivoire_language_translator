// charger vue js
var vm = new Vue({
    el: '#app',
    data: {
        product: "Socks",
        image: "./image/Logo_Ivoire.png",
        inStock: true,
        inventory: 100,
        details: ["80% cotton", "20%polyester", "gender-neutral"],
        variants: [
            {
                variantId: 2234,
                variantColor: "green",
                variantImage: "image/LogoIvoireLanguagesTranslator.png"
            }, {
                variantId: 2235,
                variantColor: "blue",
                variantImage: "Logo_Ivoire_Languages_Translator-removebg-preview.png"
            }
        ],
        cart: 0
    },
    methods: {
        addToCart() {
            this.cart += 1
        }

    },
    updateProduct(variantImage) {
        this.image = variantImage
    }
})