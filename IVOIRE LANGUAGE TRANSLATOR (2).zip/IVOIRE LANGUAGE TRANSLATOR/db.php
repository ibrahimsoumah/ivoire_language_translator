<?php
// connexion bdd
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login_utilisateur";


$conn = new mysqli($servername, $username, $password, $dbname);
