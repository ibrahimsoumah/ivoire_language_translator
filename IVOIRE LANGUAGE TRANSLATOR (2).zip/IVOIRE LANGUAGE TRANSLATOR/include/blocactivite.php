<div class="text-center bloc p-2 ">
    <div><span class="textActivite text-nowrap">ACTIVITE</span></div>
</div>
<br>