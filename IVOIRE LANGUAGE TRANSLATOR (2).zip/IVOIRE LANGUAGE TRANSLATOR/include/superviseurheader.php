<header>
    <nav class="navbar navbar-expand navbar-dark modif">
        <img src="image/LogoIvoireLanguagesTranslator(3).png" height="70" width="70" title="itl logo" alt="itl logo">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample02" aria-controls="navbarsExample02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="nav-link itltext" href="#"><span style="color: rgb(12, 199, 12);">Ivoire </span> <span style="color: rgb(255, 145, 77);"> Language </span> <span style="color: rgb(12, 199, 12);"> Translator </span></a>

        <div class="collapse navbar-collapse  p-0 d-flex justify-content-end" id="navbarsExample02">
            <ul class="navbar-nav">
                <li class="nav-item active ">
                </li>


                <li class="nav-item active ">
                    <a class="nav-link itltextE" href="superviseurAcceuil.php">ACCEUIL<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item ml-5">
                    <a class="nav-link itltextE" href="superviseurcontrole.php">CONTROLE</a>
                </li>
                <li class="nav-item ml-5">
                    <a class="nav-link itltextE" href="superviseurstatistiques.php">STATISTIQUES</a>
                </li>
                <li class="nav-item ml-5">
                    <a class="nav-link itltextE" href="superviseurparametres.php">PARAMETRES</a>
                </li>
                <li class="nav-item ml-4">
                    <a class="nav-link itltextE" href="deconnexion.php">DECONNEXION</a>
                </li>

            </ul>

        </div>
    </nav>
</header>