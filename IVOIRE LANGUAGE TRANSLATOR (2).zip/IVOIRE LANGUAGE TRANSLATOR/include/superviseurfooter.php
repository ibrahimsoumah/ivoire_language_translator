<footer class="page-footer bg-warning">
    <!-- <div class="pied">
            <span style="color: white;"><b>copyright © 2020 | Tous droits réservés</b></span>
            <span style="color: red;"><b>design by Soumah Ibrahim Michot</b></span>
        </div> -->
    <nav class="navbar fixed-bottom navbar-expand-sm navbar-dark bg-warning">

        </div>
        </li>
        </ul>
        </div>
</footer>